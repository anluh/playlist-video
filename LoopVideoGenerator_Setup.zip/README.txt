Loop Video Generator v1.0
=========================

Thank you for using Loop Video Generator!

Running the Application:
------------------------
1. Simply double-click "LoopVideoGenerator.exe" to start.

Requirements:
-------------
1. FFmpeg is REQUIRED for this application to work.
   - It must be installed and accessible via your system PATH.
   - To verify, open a Command Prompt (cmd) and type: ffmpeg -version
   - If you don't have it, download it from https://ffmpeg.org/download.html

Troubleshooting:
----------------
- If the app opens and closes immediately, ensure FFmpeg is installed.
- Check the "SafeToAutoRun" equivalent: ensure you have permissions to write to the output folder.

Enjoy!
